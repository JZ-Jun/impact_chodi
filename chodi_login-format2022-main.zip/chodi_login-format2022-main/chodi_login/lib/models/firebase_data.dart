class FirebaseDataModel {
  List<dynamic> dataList;

  FirebaseDataModel({required this.dataList});
}
